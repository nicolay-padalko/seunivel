<template>
    <top-bar/>
    <div class="flex justify-center min-h-screen bg-indigo-200">

        <div class="w-5/6 lg:w-2/3">
            <div class="flex flex-row">
                <div class="flex-auto p-2 lg:p-6">
                    <div class="flex justify-center">
                        <h1 class="text-4xl font-bold pt-12 text-blue-800">
                            Teste da língua Inglesa.
                        </h1>
                    </div>
                    <div class="flex justify-center">
                        <p class="text-2xl pt-12">
                            O teste é composto em 3 partes.<br>
                            Parte 1 perguntas de múltipla escolha.<br>
                            Parte 2 leitura e interpretação de texto.<br>
                            Parte 3 escrita.<br>
                            Reservar 60 minutos para seu teste, uma vez iniciado o teste, ele não pode ser pausado ou
                            reiniciado.
                            Certifique que
                            sua conexão com a internet está estável.
                            O teste pode ser feito no smartphone, recomendamos que seja feito no computador para melhor
                            digitação e leitura.

                        </p>

                    </div>

                </div>

            </div>
            <div class="flex justify-center">
                <a href="/question">
                    <button
                        class="bg-blue-500 p-3 font-medium rounded-lg text-center w-72">
                        Start Test
                    </button>
                </a>

            </div>
        </div>
    </div>

</template>

<script setup>

import TopBar from "@/Pages/Components/TopBar.vue";


</script>

<style scoped>

</style>
