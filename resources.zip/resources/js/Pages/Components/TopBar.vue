<script setup>

</script>

<template>
    <div class="bg-indigo-800">
        <div class="flex flex-row">
            <div class="basis-1/4">
                <img class="w-36 m-6" src="images/logo-EM.svg" alt="">
            </div>
            <div class="basis-3/4 text-center text-white font-medium pt-20">
<!--                <a href="#" class="hover:text-yellow-400 p-6">Teste de Inglês</a>-->
<!--                <a href="#" class="hover:text-yellow-400 p-6">Login</a>-->
<!--                <a href="#" class="hover:text-yellow-400 p-6">cadastre sua empresa</a>-->
            </div>
        </div>

    </div>
</template>

<style scoped>

</style>
